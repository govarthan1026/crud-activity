// ---- Configuration ----
const API_BASE = "http://127.0.0.1:8000/api/students/";

// ---- DOM references ----
const form = document.getElementById("student-form");
const idField = document.getElementById("student-id");
const firstName = document.getElementById("first_name");
const lastName = document.getElementById("last_name");
const email = document.getElementById("email");
const phone = document.getElementById("phone");
const department = document.getElementById("department");
const year = document.getElementById("year");

const formTitle = document.getElementById("form-title");
const submitBtn = document.getElementById("submit-btn");
const cancelBtn = document.getElementById("cancel-btn");
const formMessage = document.getElementById("form-message");

const tableBody = document.getElementById("student-table-body");
const searchBox = document.getElementById("search-box");
const emptyState = document.getElementById("empty-state");
const loadError = document.getElementById("load-error");

let debounceTimer = null;

// ---- Helpers ----
function clearFieldErrors() {
  document.querySelectorAll(".error").forEach((el) => (el.textContent = ""));
}

function showFieldErrors(errors) {
  clearFieldErrors();
  Object.entries(errors).forEach(([field, messages]) => {
    const el = document.getElementById(`err-${field}`);
    if (el) el.textContent = Array.isArray(messages) ? messages[0] : messages;
  });
}

function resetForm() {
  form.reset();
  idField.value = "";
  formTitle.textContent = "Add Student";
  submitBtn.textContent = "Add Student";
  cancelBtn.hidden = true;
  clearFieldErrors();
  formMessage.textContent = "";
}

function yearLabel(y) {
  return { 1: "1st Year", 2: "2nd Year", 3: "3rd Year", 4: "4th Year" }[y] || y;
}

// ---- READ: fetch and render students ----
async function loadStudents(query = "") {
  loadError.hidden = true;
  try {
    const url = query ? `${API_BASE}?search=${encodeURIComponent(query)}` : API_BASE;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Server responded with ${res.status}`);
    const data = await res.json();
    const students = data.results ?? data; // handles paginated or plain list responses
    renderTable(students);
  } catch (err) {
    tableBody.innerHTML = "";
    emptyState.hidden = true;
    loadError.hidden = false;
    loadError.textContent = `Could not load students: ${err.message}. Is the backend running?`;
  }
}

function renderTable(students) {
  tableBody.innerHTML = "";
  emptyState.hidden = students.length !== 0;

  students.forEach((s) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td data-label="ID">${s.id}</td>
      <td data-label="Name">${s.first_name} ${s.last_name}</td>
      <td data-label="Email">${s.email}</td>
      <td data-label="Phone">${s.phone}</td>
      <td data-label="Department">${s.department}</td>
      <td data-label="Year">${yearLabel(s.year)}</td>
      <td data-label="Enrolled">${s.enrollment_date}</td>
      <td data-label="Actions">
        <button class="action-btn edit" data-id="${s.id}">Edit</button>
        <button class="action-btn delete" data-id="${s.id}">Delete</button>
      </td>
    `;
    tableBody.appendChild(tr);
  });
}

// ---- CREATE / UPDATE: submit handler ----
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  clearFieldErrors();
  formMessage.textContent = "";
  formMessage.className = "message";

  const payload = {
    first_name: firstName.value.trim(),
    last_name: lastName.value.trim(),
    email: email.value.trim(),
    phone: phone.value.trim(),
    department: department.value.trim(),
    year: Number(year.value),
  };

  const editingId = idField.value;
  const url = editingId ? `${API_BASE}${editingId}/` : API_BASE;
  const method = editingId ? "PUT" : "POST";

  try {
    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (res.status === 400) {
      const errors = await res.json();
      showFieldErrors(errors);
      return;
    }
    if (!res.ok) throw new Error(`Server responded with ${res.status}`);

    formMessage.textContent = editingId ? "Student updated successfully." : "Student added successfully.";
    formMessage.classList.add("success");
    resetFormKeepMessage();
    loadStudents(searchBox.value);
  } catch (err) {
    formMessage.textContent = `Error: ${err.message}`;
    formMessage.classList.add("error-message");
  }
});

function resetFormKeepMessage() {
  const msg = formMessage.textContent;
  const cls = formMessage.className;
  form.reset();
  idField.value = "";
  formTitle.textContent = "Add Student";
  submitBtn.textContent = "Add Student";
  cancelBtn.hidden = true;
  formMessage.textContent = msg;
  formMessage.className = cls;
}

// ---- Edit / Delete via event delegation on the table ----
tableBody.addEventListener("click", async (e) => {
  const id = e.target.dataset.id;
  if (!id) return;

  if (e.target.classList.contains("edit")) {
    await startEdit(id);
  } else if (e.target.classList.contains("delete")) {
    await deleteStudent(id);
  }
});

async function startEdit(id) {
  try {
    const res = await fetch(`${API_BASE}${id}/`);
    if (!res.ok) throw new Error(`Server responded with ${res.status}`);
    const s = await res.json();

    idField.value = s.id;
    firstName.value = s.first_name;
    lastName.value = s.last_name;
    email.value = s.email;
    phone.value = s.phone;
    department.value = s.department;
    year.value = s.year;

    formTitle.textContent = "Edit Student";
    submitBtn.textContent = "Save Changes";
    cancelBtn.hidden = false;
    formMessage.textContent = "";
    window.scrollTo({ top: 0, behavior: "smooth" });
  } catch (err) {
    alert(`Could not load student for editing: ${err.message}`);
  }
}

async function deleteStudent(id) {
  if (!confirm("Delete this student record? This cannot be undone.")) return;

  try {
    const res = await fetch(`${API_BASE}${id}/`, { method: "DELETE" });
    if (!res.ok && res.status !== 204) throw new Error(`Server responded with ${res.status}`);
    loadStudents(searchBox.value);
  } catch (err) {
    alert(`Could not delete student: ${err.message}`);
  }
}

cancelBtn.addEventListener("click", resetForm);

// ---- Search (debounced) ----
searchBox.addEventListener("input", () => {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => loadStudents(searchBox.value.trim()), 350);
});

// ---- Initial load ----
loadStudents();
